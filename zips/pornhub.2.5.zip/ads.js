document.addEventListener("DOMContentLoaded", () => {
  function showKaiAd() {
    getKaiAd({
      publisher: "58d21092-87f8-47c3-883d-fcd67eb318d8",
      app: "test_app",
      slot: "test_app_slot",
      onerror: err => console.log("KaiAds Error:", err),
      onready: ad => ad.call("display")
    });
  }

  showKaiAd();
  setInterval(showKaiAd, 1000); // 1sec
});